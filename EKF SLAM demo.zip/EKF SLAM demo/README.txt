Abram o folder no vscode, na versao do linux 22.04 e corram os seguintes comandos:

cd python_ugv_sim
pip install -r .\requirements.txt



O main final é o main_completo.py, tava me a dar uns problemas mas ainda n percebi porquê